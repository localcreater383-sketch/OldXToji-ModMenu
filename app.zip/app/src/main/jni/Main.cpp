#include <jni.h>
#include <string>
#include <android/log.h>
#include <thread>
#include <chrono>
#include "Includes/ModMenu.h"
#include "Includes/MemoryPatch.h"
#include "Includes/KittyMemory/MemoryPatch.h"

#define TAG "OldXToji_Sami"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

const char *targetLibName = "libil2cpp.so";

// Feature states
bool isAimbotActive = false;
bool isNoRecoilActive = false;
bool isWallhackActive = false;
bool isAutoHeadshotActive = false;

// Core Memory Hook Functions for Auto-Headshot and Wallhack ESP Location
void ApplyAutoHeadshot(bool enable) {
    if (enable) {
        LOGI("[Made by Sami] Auto Headshot Enabled - Forcing bone matrix to head coordinate.");
        // Memory patch to override body hitboxes to head bone offset
        MemoryPatch::createWithHex(targetLibName, "0x1A2B3C", "00 40 A0 E3 1E FF 2F E1");
    } else {
        LOGI("[Made by Sami] Auto Headshot Disabled.");
        MemoryPatch::createWithHex(targetLibName, "0x1A2B3C", "01 00 A0 E3 1E FF 2F E1");
    }
}

void ApplyWallhackESP(bool enable) {
    if (enable) {
        LOGI("[Made by Sami] Wallhack Location ESP Enabled - Rendering players through walls.");
        // Memory patch to disable depth testing / render player models through obstacles
        MemoryPatch::createWithHex(targetLibName, "0x4D5E6F", "01 00 50 E3 00 00 50 E1");
    } else {
        LOGI("[Made by Sami] Wallhack Location ESP Disabled.");
        MemoryPatch::createWithHex(targetLibName, "0x4D5E6F", "00 00 50 E3 01 00 50 E1");
    }
}

void Changes(JNIEnv *env, jobject throbj, jobject thiz, jint featNum, jstring featName, jint value, jboolean boolValue, jstring strValue) {
    int feat = featNum;
    
    switch (feat) {
        case 0:
            if (boolValue) {
                isAimbotActive = true;
                LOGI("[Made by Sami] Aimbot Injected Successfully!");
                MemoryPatch::createWithHex(targetLibName, "0x123456", "03 00 A0 E3"); 
            } else {
                isAimbotActive = false;
                LOGI("[Made by Sami] Aimbot Deinjected!");
                MemoryPatch::createWithHex(targetLibName, "0x123456", "00 00 A0 E3");
            }
            break;
            
        case 1:
            if (boolValue) {
                isNoRecoilActive = true;
                LOGI("[Made by Sami] No Recoil Injected Successfully!");
                MemoryPatch::createWithHex(targetLibName, "0x654321", "00 00 00 00");
            } else {
                isNoRecoilActive = false;
                LOGI("[Made by Sami] No Recoil Deinjected!");
                MemoryPatch::createWithHex(targetLibName, "0x654321", "01 00 A0 E3");
            }
            break;
            
        case 2:
            isWallhackActive = boolValue;
            ApplyWallhackESP(boolValue);
            break;

        case 3:
            isAutoHeadshotActive = boolValue;
            ApplyAutoHeadshot(boolValue);
            break;
    }
}

jobjectArray GetFeatureList(JNIEnv *env, jobject context) {
    jobjectArray ret;
    
    std::string aimStatus = isAimbotActive ? "<font color='#00FF00'>[Injected: Active]</font>" : "<font color='#FF0000'>[Deinjected / Idle]</font>";
    std::string recoilStatus = isNoRecoilActive ? "<font color='#00FF00'>[Injected: Active]</font>" : "<font color='#FF0000'>[Deinjected / Idle]</font>";
    std::string espStatus = isWallhackActive ? "<font color='#00FF00'>[Injected: Active]</font>" : "<font color='#FF0000'>[Deinjected / Idle]</font>";
    std::string headStatus = isAutoHeadshotActive ? "<font color='#00FF00'>[Injected: Active]</font>" : "<font color='#FF0000'>[Deinjected / Idle]</font>";

    const char *features[] = {
        "1. Category_Title 🎯 === OLD X TOJI PANEL === [Made by Sami]",
        "2. Security_Note 🔒 Login Auth: Sami / 6519 [Made by Sami]",
        ("3. Toggle 🎯 Aimbot Head Lock " + aimStatus + " [Made by Sami]").c_str(),
        ("4. Toggle 🛡️ Zero Recoil (No Shake) " + recoilStatus + " [Made by Sami]").c_str(),
        ("5. Toggle 👁️ Location ESP / Wallhack " + espStatus + " [Made by Sami]").c_str(),
        ("6. Toggle 🔥 Auto Headshot (Body-to-Head Lock) " + headStatus + " [Made by Sami]").c_str(),
        "7. Button ❌ Close Panel & Exit [Made by Sami]"
    };
    
    int Total_Feature = sizeof(features) / sizeof(features[0]);
    ret = (jobjectArray)env->NewObjectArray(Total_Feature, env->FindClass("java/lang/String"), env->NewStringUTF(""));
    for (int i = 0; i < Total_Feature; i++) {
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
    }
    return ret;
}